# Detection-of-Anxiety-and-Depression
Detecting Anxiety and Depression using facial emotion recognition and speech emotion recognition. Written in pythonPython

INSTRUCTIONS 
Clone the repository

1. pip install virtualenv
2. face/Scripts/activate
3. cd Realtime-Emotion-Detection
4. pip install -r requirements.txt
5. pip install PyAudio-0.2.11-cp39-cp39-win_amd64.whl // if processor is amd run this command 
   pip install PyAudio-0.2.11-cp39-cp39-win32.whl // if processor is intel run this command 
6. flask run 
